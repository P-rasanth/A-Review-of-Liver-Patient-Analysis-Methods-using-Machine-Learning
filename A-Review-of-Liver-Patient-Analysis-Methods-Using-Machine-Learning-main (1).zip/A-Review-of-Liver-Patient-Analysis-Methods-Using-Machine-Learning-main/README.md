# A-Review-of-Liver-Patient-Analysis-Methods-Using-Machine-Learning
video demonstration:https://drive.google.com/file/d/18oqYpiwektOhwy-gUO71F_GDpkSWjoJU/view?usp=drivesdk
